<?php

namespace App\Http\Controllers;

use Response;
use Illuminate\Routing\Controller;
use App\Http\Requests\FormTestValidation;

class BaseController extends Controller {

/* any other shared functions can go here */

}